#include <stdio.h>

int main()
{

    int A[5][10];
    int *p1 = &A[0][0]; //Con tro toi kieu int
//p1 = A[0], A[0] la tuong duong voi &A[0][0]
    int (*p2)[10] = &A[0]; //Con tro tro toi mang 1 chieu 10 phan tu
//p2 = A
    int (*p3)[5][10] = &A; //Con tro tro toi mang 2 chieu kich thuoc 5x10

    p1++; //p1 tro toi A[0][1]
    printf("\np1 = %p - &A[0][1] = %p", p1, &A[0][1]);
    p2++; //p2 tro toi A[1][0]
    printf("\np2 = %p - &A[1][0] = %p", p2, &A[1][0]);
    p3++; //p3 tro toi sau mang A, p3 = &A[5][10] + 1 (4 byte)
    printf("\np3 = %p - &A[4][9]+ 4 = %p", p3, &A[4][9] + 1);
    printf("\n&A = %p - A = %p - A[0] = %p \n&A[0][0] = %p\n", &A, A, A[0], &A[0][0]);
    p3 = &A[0][0];
    return 0;
}
