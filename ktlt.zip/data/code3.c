
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

//Truyen vao so phan tu va day cac phan tu
int tong(int n, ...)
{
  va_list ap;
  va_start(ap, n); //tham so co dinh cuoi cung
  int value, s = 0, i;
  for (i=0; i<n; i++)
  {
    value = va_arg(ap, int);
    s = s + value;
  }
  va_end(ap);
  return s;
}

int main()
{
  int a, b;
  a = tong(5, 1, 2, 3, 4, 5);
  printf("a = %d", a);
  b = tong(9, 1, 2, 3, 4, 5, 6, 7, 8, 9);
  printf("\nb = %d\n", b);
  return 0;
}
