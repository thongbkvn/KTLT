#include <stdio.h>
#include <stdlib.h>

char* func()
{
    char s[10];
    printf("Nhap xau s: ");
    fgets(s, 10, stdin);
    return s;
}
int func2()
{
    char s[10] = "DHBKHN";
}
int main()
{
    char *t;
    t = func();
    func2();
    printf("Xau t: \"%s\"\n", t);
}
